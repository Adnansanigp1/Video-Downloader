package com.vd.downloader

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import java.util.concurrent.CountDownLatch

/** yt-dlp + ffmpeg একবার চালু করে (প্রথমবার কিছুটা সময় লাগে)। */
object Engine {
    private val latch = CountDownLatch(1)

    @Volatile
    var error: String? = null

    fun init(app: Application) {
        Thread {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
            } catch (e: Throwable) {
                error = e.message ?: e.toString()
            } finally {
                latch.countDown()
            }
        }.start()
    }

    fun await() {
        latch.await()
        error?.let { throw IllegalStateException("Engine init failed: $it") }
    }
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Engine.init(this)
    }
}
